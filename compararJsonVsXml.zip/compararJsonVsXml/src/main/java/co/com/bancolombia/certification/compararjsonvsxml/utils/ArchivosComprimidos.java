package co.com.bancolombia.certification.compararjsonvsxml.utils;

import java.awt.List;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

public class ArchivosComprimidos {

	public ArchivosComprimidos() {
		super();
		// TODO Auto-generated constructor stub
	}

	public static void delete(File file) {
		if (file.isDirectory()) {
			if (file.list().length == 0) {
				file.delete();
			} else {
				String files[] = file.list();
				for (String temp : files) {
					File fileDelete = new File(file, temp);
					delete(fileDelete);
				}
				if (file.list().length == 0) {
					file.delete();
				}
			}
		} else {
			file.delete();
		}
	}

	public boolean comparateAttachments(ArrayList<String> filesJSON, String[] filesFolder) {
		String listFileJSON[] = new String[filesJSON.size()];
		for (int j = 0; j < filesJSON.size(); j++) {
			listFileJSON[j] = filesJSON.get(j);
		}
		ArrayList<String> arrFilesFolder = new ArrayList<String>();
		for (int i = 0; i < filesFolder.length; i++) {
			arrFilesFolder.add(filesFolder[i]);
		}
		
			return filesJSON.containsAll(Arrays.asList(filesFolder))
				&& arrFilesFolder.containsAll(Arrays.asList(listFileJSON));
	}

	public String[] getNamesFiles(String routeFiles) {
		File folder = new File(routeFiles);
		File[] listOfFiles = folder.listFiles();
		String name = "";
		String names[] = new String[listOfFiles.length];

		for (int i = 0; i < listOfFiles.length; i++) {
			name = listOfFiles[i].getName();
			names[i] = name;
		}
		return names;
	}

}
