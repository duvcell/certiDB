package co.com.bancolombia.certification.compararjsonvsxml.models;

public class NombreArchivoJson {

	private String sNombreArchivo;

	public NombreArchivoJson() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getsNombreArchivo() {
		return sNombreArchivo;
	}

	public void setsNombreArchivo(String sNombreArchivo) {
		this.sNombreArchivo = sNombreArchivo;
	}
	
	
}
