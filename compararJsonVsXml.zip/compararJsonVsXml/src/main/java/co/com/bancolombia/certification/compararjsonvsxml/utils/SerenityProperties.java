package co.com.bancolombia.certification.compararjsonvsxml.utils;

import net.thucydides.core.util.SystemEnvironmentVariables;

public class SerenityProperties {

	//Variable que almacena la ubicaci�n del Json Local
	public static String sPATH_JSON_FILE = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("PATH_JSON_FILE");

	//Variable que almacena la ubicaci�n del Xml Local, faltando el nombre del archivo
	public static String sPATH_XML_FILE = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("PATH_XML_FILE");
	
	//Variable que almacena la ubicaci�n del Log Local, con el nombre del archivo
	public static String sPATH_LOG_FILE = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("PATH_LOG_FILE");
	
	//Variable que almacena el usuario para acceder al Lotus
	public static String sURL_SERVER = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("URL_SERVER");
	
	//Variable que almacena el usuario para acceder al Lotus
	public static String sUSER_NAME = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("USER_NAME");
	
	//Variable que almacena la contrase�a para acceder al Lotus
	public static String sPASSWORD = SystemEnvironmentVariables.createEnvironmentVariables().getProperty("PASSWORD");
	
}
